declare module "_102022_/l2/agentLucas.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/agentLucas" {
    import { IAgent } from '/_100554_/l2/aiAgentBase';
    import './_100554_widgetQuestionsForClarification';
    export function createAgent(): IAgent;
    export interface PayloadResultOk {
        pageHtml: string;
        result: mls.l4.BaseDefs;
    }
}
declare module "_102022_/l2/agentNewMiniApp.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/agentNewMiniApp" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    import '/_100554_/l2/widgetQuestionsForClarification.js';
    export function createAgent(): IAgent;
    export interface PayloadUpdate {
        defs: mls.l4.BaseDefs;
        isUpdate: boolean;
    }
}
declare module "_102022_/l2/agentUpdateMiniApp.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/agentUpdateMiniApp" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    import '/_100554_/l2/widgetQuestionsForClarification.js';
    export function createAgent(): IAgent;
    export interface PayloadOk {
        pageTs: string;
        pageHtml: string;
        defs: mls.l4.BaseDefs;
        pageLess?: string;
        isUpdate: boolean;
    }
    export interface PayloadUpdate {
        defs?: mls.l4.BaseDefs;
        prompt?: string;
        isUpdate: boolean;
    }
}
declare module "_102022_/l2/collabRunTime.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/config.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/config" {
    import { Aura } from '/_102020_/l2/aura';
    export var aura: Aura | undefined;
}
declare module "_102022_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/designSystem" {
    import { IDesignSystemTokens } from '/_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102022_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: {
            name: string;
            path: string;
            auth: string;
        }[];
    };
}
declare module "_102022_/l2/ecommerce/module.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/ecommerce/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: {
            pageName: string;
            title: string;
            auth: string;
            icon: string;
        }[];
    };
}
declare module "_102022_/l2/ecommerce/shopeeFeeCalculator.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102022_/l2/ecommerce/shopeeFeeCalculator.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/ecommerce/shopeeFeeCalculator" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class EcommerceShopeeFeeCalculator102022 extends CollabPageElement {
        price: number;
        cost: number;
        freight: number;
        discount: number;
        commissionPercent: number;
        paymentFeePercent: number;
        constructor();
        initPage(): void;
        onInputNumber(e: Event): void;
        compute(): {
            commissionValue: number;
            paymentFeeValue: number;
            totalFees: number;
            costTotal: number;
            profit: number;
            margin: number;
        };
        saveHistory(): void;
        exportCsv(): void;
        getHistoryArray(): any[];
        deleteHistory(index: number): void;
        clearHistory(): void;
        renderHistory(): any;
        renderInputs(): any;
        render(): any;
    }
}
declare module "_102022_/l2/finance/invoiceGeneratorPage.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102022_/l2/finance/invoiceGeneratorPage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/finance/invoiceGeneratorPage" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class InvoiceGeneratorPage extends CollabPageElement {
        constructor();
        initPage(): void;
        private calculateTotals;
        private onClientChange;
        private onItemChange;
        private addItem;
        private removeItem;
        private generatePdf;
        private downloadPdf;
        private sendEmail;
        private notify;
        render(): any;
    }
}
declare module "_102022_/l2/finance/module.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/finance/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: {
            pageName: string;
            title: string;
            auth: string;
            icon: string;
        }[];
    };
}
declare module "_102022_/l2/generalutilities/module.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/generalutilities/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: {
            pageName: string;
            title: string;
            auth: string;
            icon: string;
        }[];
    };
}
declare module "_102022_/l2/generalutilities/passwordStrengthChecker.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102022_/l2/generalutilities/passwordStrengthChecker.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/generalutilities/passwordStrengthChecker" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PasswordStrengthCheckerPage extends CollabPageElement {
        password: string;
        showPassword: boolean;
        score: number;
        strengthLabel: string;
        suggestions: string[];
        private inputDebounceTimer;
        constructor();
        initPage(): void;
        connectedCallback(): void;
        onInput(e: Event): void;
        onPaste(e: ClipboardEvent): void;
        toggleShow(): void;
        evaluatePassword(pwd: string): void;
        meterColor(score: number): "bg-red-500" | "bg-yellow-500" | "bg-green-500";
        render(): any;
    }
}
declare module "_102022_/l2/generalutilities/timeConverter.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102022_/l2/generalutilities/timeConverter.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/generalutilities/timeConverter" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class TimeConverterPage extends CollabPageElement {
        inputValue: string;
        fromUnit: 'hours' | 'minutes' | 'seconds';
        toUnit: 'hours' | 'minutes' | 'seconds';
        resultValue: string;
        formatAsHHMMSS: boolean;
        isDark: boolean;
        mediaQuery: any;
        initPage(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleColorSchemeChange: (e: any) => void;
        parseToSeconds(text: string, assumedUnit: 'hours' | 'minutes' | 'seconds'): number;
        formatFromSeconds(seconds: number, targetUnit: 'hours' | 'minutes' | 'seconds', asHHMMSS: boolean): string;
        convert(): void;
        swapDirections(): void;
        clearAll(): void;
        copyResult(): Promise<void>;
        onInputChange(e: any): void;
        onFromChange(e: any): void;
        onToChange(e: any): void;
        onToggleFormat(): void;
        render(): any;
    }
}
declare module "_102022_/l2/generalutilities/tipCalculator.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102022_/l2/generalutilities/tipCalculator.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/generalutilities/tipCalculator" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class TipCalculatorPage extends CollabPageElement {
        constructor();
        initPage(): void;
        formatCurrency(value: number): string;
        parseNumber(value: string): number;
        onBillInput(e: any): void;
        onSelectTip(percent: number): void;
        onCustomTipInput(e: any): void;
        onPeopleInput(e: any): void;
        onRoundingChange(e: any): void;
        compute(): {
            billAmount: number;
            tipPercent: number;
            tipTotal: number;
            totalWithTip: number;
            perPerson: number;
            tipPerPerson: number;
            people: number;
            rounding: any;
        };
        render(): any;
    }
}
declare module "_102022_/l2/reports/module.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/reports/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: {
            pageName: string;
            title: string;
            auth: string;
            icon: string;
        }[];
    };
}
declare module "_102022_/l2/reports/monthlySales.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102022_/l2/reports/monthlySales.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/reports/monthlySales" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class ReportsMonthlySales102022 extends CollabPageElement {
        constructor();
        initPage(): void;
        fetchData(): Promise<void>;
        applyFilters(): void;
        exportCSV(): void;
        exportPDF(): void;
        render(): any;
    }
}
