declare module "_102022_/l2/miniApps/module" {
    import type { MasterFrontendModuleFrontendDefinition } from '_102029_/l2/contracts/bootstrap';
    export const moduleFrontendDefinition: MasterFrontendModuleFrontendDefinition;
}
declare module "_102022_/l2/miniApps/web/desktop/page11/monthlySales" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class MiniAppsDesktopPage11MonthlySalesPage extends StateLitElement {
        private msg;
        private csvText;
        private filter;
        private setCsv;
        private openFile;
        private renderKpi;
        private renderProblems;
        private renderTable;
        private renderReport;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102022_/l2/miniApps/web/desktop/page11/passwordStrengthChecker" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class MiniAppsDesktopPage11PasswordStrengthCheckerPage extends StateLitElement {
        private msg;
        private password;
        private visible;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102022_/l2/miniApps/web/desktop/page11/shopeeFeeCalculator" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class MiniAppsDesktopPage11ShopeeFeeCalculatorPage extends StateLitElement {
        private msg;
        private sale;
        private history;
        private setHistory;
        private renderField;
        private renderRow;
        private renderHistory;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102022_/l2/miniApps/web/desktop/page11/timeConverter" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class MiniAppsDesktopPage11TimeConverterPage extends StateLitElement {
        private msg;
        private text;
        private from;
        private to;
        private asClock;
        private copyStatus;
        private result;
        private swap;
        private copy;
        private renderUnitSelect;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102022_/l2/miniApps/web/desktop/page11/tipCalculator" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class MiniAppsDesktopPage11TipCalculatorPage extends StateLitElement {
        private msg;
        private bill;
        private preset;
        private customPercent;
        private people;
        private rounding;
        private get tipPercent();
        private renderPresetButton;
        private renderTipField;
        private renderResultRow;
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102022_/l2/miniApps/web/shared/csv" {
    export type CsvCell = string | number;
    export function toCsv(headers: string[], rows: CsvCell[][]): string;
    /**
     * Parses CSV text into rows of cells. The delimiter is `,` or `;`, whichever the first line
     * uses more. Quoted cells may hold delimiters, quotes (`""`) and line breaks. Blank lines are dropped.
     */
    export function parseCsv(text: string): string[][];
}
declare module "_102022_/l2/miniApps/web/shared/monthlySales" {
    export interface SaleRow {
        date: string;
        order: string;
        customer: string;
        product: string;
        quantity: number;
        amount: number;
        status: string;
    }
    export type RowProblem = 'badDate' | 'badAmount';
    export interface ParsedSales {
        rows: SaleRow[];
        missingColumns: Array<'date' | 'amount'>;
        problems: Array<{
            row: number;
            problem: RowProblem;
        }>;
    }
    export interface SalesSummary {
        total: number;
        orders: number;
        averageTicket: number;
    }
    export interface SalesFilter {
        month: string;
        status: string;
        query: string;
    }
    export const SALES_COLUMNS: readonly ['date', 'order', 'customer', 'product', 'quantity', 'amount', 'status'];
    export const SAMPLE_CSV: string;
    /** `1234.56`, `1,234.56`, `1.234,56` or `1234,56`; currency signs and spaces are ignored. */
    export function parseAmount(text: string): number | null;
    export function parseSalesCsv(text: string): ParsedSales;
    /** Rows with the same order id are one order; rows without an id count one each. */
    export function summarize(rows: SaleRow[]): SalesSummary;
    export function monthsOf(rows: SaleRow[]): string[];
    export function statusesOf(rows: SaleRow[]): string[];
    export function filterSales(rows: SaleRow[], f: SalesFilter): SaleRow[];
    export function salesToCsv(rows: SaleRow[]): string;
}
declare module "_102022_/l2/miniApps/web/shared/passwordStrengthChecker" {
    export type StrengthLevel = 'weak' | 'medium' | 'strong';
    export type Suggestion = 'minLength' | 'longer' | 'addUpper' | 'addDigit' | 'addSymbol' | 'avoidCommon' | 'avoidRepeats';
    export interface PasswordStrength {
        score: number;
        level: StrengthLevel;
        suggestions: Suggestion[];
    }
    /** Local heuristic: length, character variety and an entropy estimate, minus common patterns. */
    export function evaluatePassword(pwd: string): PasswordStrength;
}
declare module "_102022_/l2/miniApps/web/shared/shopeeFeeCalculator" {
    export const DEFAULT_COMMISSION_PERCENT = 12;
    export const DEFAULT_PAYMENT_FEE_PERCENT = 2.5;
    export const HISTORY_LIMIT = 200;
    export interface SaleInput {
        price: number;
        cost: number;
        freight: number;
        discount: number;
        commissionPercent: number;
        paymentFeePercent: number;
    }
    export interface FeeResult {
        commission: number;
        paymentFee: number;
        totalFees: number;
        totalCost: number;
        profit: number;
        margin: number;
    }
    export interface HistoryEntry extends SaleInput, Pick<FeeResult, 'totalFees' | 'profit' | 'margin'> {
        date: string;
    }
    /** Marketplace fees are charged on the listed price; the discount only reduces what you receive. */
    export function computeFees(input: SaleInput): FeeResult;
    export function addToHistory(history: HistoryEntry[], input: SaleInput, now: Date): HistoryEntry[];
    /** Keeps only well-formed entries, so a damaged saved history never breaks the page. */
    export function readHistory(raw: string | null): HistoryEntry[];
    export function historyToCsv(history: HistoryEntry[]): string;
}
declare module "_102022_/l2/miniApps/web/shared/timeConverter" {
    export type TimeUnit = 'hours' | 'minutes' | 'seconds';
    /**
     * Reads a duration as seconds. Accepts `h:mm:ss`, `mm:ss` or a plain number in `unit`
     * (`1.5` or `1,5`). Empty or invalid text gives null; negative values are refused.
     */
    export function parseToSeconds(text: string, unit: TimeUnit): number | null;
    export function secondsTo(seconds: number, unit: TimeUnit): number;
    /** `h:mm:ss`, hours not capped at 24. */
    export function formatClock(seconds: number): string;
}
declare module "_102022_/l2/miniApps/web/shared/tipCalculator" {
    export type Rounding = 'none' | 'up' | 'down' | 'nearest';
    export const TIP_PRESETS: readonly [10, 15, 20];
    export interface TipInput {
        bill: number;
        tipPercent: number;
        people: number;
        rounding: Rounding;
    }
    export interface TipResult {
        tipTotal: number;
        total: number;
        tipPerPerson: number;
        /** Total per person, after the chosen rounding. */
        perPerson: number;
    }
    export function roundAmount(value: number, rounding: Rounding): number;
    export function computeTip(input: TipInput): TipResult;
}
declare module "_102022_/l2/miniApps/web/shared/ui" {
    export const fieldClass = "w-full rounded-md border border-[var(--border-default,currentColor)] bg-[var(--input-bg,transparent)] px-3 py-2 text-[var(--text-default,currentColor)] focus:outline-2 focus:outline-[var(--focus-ring,currentColor)]";
    export const labelClass = "mb-1 block text-sm font-medium text-[var(--text-default,currentColor)]";
    export const cardClass = "rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-6";
    export const panelClass = "rounded-md border border-[var(--border-subtle,currentColor)] bg-[var(--surface-alt-bg,transparent)] p-4";
    export const primaryButtonClass = "rounded-md border border-transparent bg-[var(--button-primary-bg,currentColor)] px-4 py-2 text-sm font-medium text-[var(--button-primary-text,canvas)] focus:outline-2 focus:outline-[var(--focus-ring,currentColor)] disabled:opacity-50";
    export const secondaryButtonClass = "rounded-md border border-[var(--button-secondary-border,currentColor)] bg-[var(--button-secondary-bg,transparent)] px-3 py-2 text-sm font-medium text-[var(--button-secondary-text,currentColor)] focus:outline-2 focus:outline-[var(--focus-ring,currentColor)] disabled:opacity-50";
    export function fmtAmount(value: number): string;
    export function fmtNumber(value: number, maxDecimals?: number): string;
    /** Hands the text to the browser as a file download. */
    export function downloadText(filename: string, text: string, type?: string): void;
    /** Value of a number input; empty or invalid reads as 0. */
    export function numberOf(e: Event): number;
}
declare module "_102022_/l2/project" {
    export const projectConfig: {
        modules: {
            name: string;
            path: string;
        }[];
    };
}
declare module "_102022_/l2/project.defs" {

}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from '_102029_/l2/runtimeConfigTypes';
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        /**
         * The environment mode the SERVER resolved for this project (`production | homologation | development |
         * presentation`). The client only displays it; it never decides it. Absent on a runtime older than the
         * modes.
         */
        appEnv?: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        languages?: string[];
        designSystem?: string;
        designSystems?: string[];
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
        /** Present only when server onboarding is enabled. Paths belong to the client module, not the page being served. */
        onboarding?: {
            entryPath: string;
            moduleBasePath: string;
        };
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
            /** Unified nav3 (runtime): content-region tabs hosting arbitrary elements. */
            collabRuntimeNav3?: {
                openTab: (tab: {
                    id: string;
                    title: string;
                    element: unknown;
                    closable?: boolean;
                }) => void;
                closeTab: (id: string) => void;
                activateTab: (id: string) => void;
                listTabs: () => string[];
                /** Id of the tab the bar is showing (`app` or `mod-<basePath>`). */
                activeTab: () => string;
                /**
                 * The element hosted by the tab on screen (an HTMLElement; typed unknown like `openTab`): the app region host
                 * for `app`, the element given to `openTab` otherwise. Null while it is not rendered yet. A change of tab is
                 * announced on window as `collab-nav3-tab-change`.
                 */
                activeTabElement?: () => unknown;
                togglePin: (id: string) => void;
                isPinned: (id: string) => boolean;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        languages?: string[];
        designSystems?: string[];
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    /** Where this project is read from and saved to. Replaces the `cadastro` blob. */
    export interface ProjectSettingsConfig {
        /** Destination: 'GitHub' | 'GitLab' | 'vm'. Routed by getDefaultDriver in the cfe. */
        driver: string;
        /** >= 3 '/'-separated segments: getMyKeysBranch takes the LAST three as branch/owner/repo. */
        url: string;
        name?: string;
        userAuth?: 'public' | 'private';
    }
    /** Optional cadastro module. It does not decide whether the organization exists. */
    export interface ProjectOnboardingConfig {
        moduleId: string;
        entryPath: string;
        personType: string;
        companyType: string;
        /**
         * Transitional. Prefer `ProjectsConfig.organization.source`.
         * Used only when `organization` itself was omitted. Ignored when that field is set.
         */
        organizationSource?: 'project-file' | 'development-project';
        /** Automatic entry into cadastro. Absent equals true. false keeps provisioning and does not redirect. */
        redirect?: boolean;
    }
    /** Organization identity source. Independent of the cadastro module. Absent `source` means project-file. */
    export interface ProjectOrganizationConfig {
        source?: 'project-file' | 'development-project';
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        clientShell?: ProjectClientShellConfig;
        /** Optional same-origin favicon href (`/…`). Cross-origin values are ignored. */
        favicon?: string;
        /** Destination of this project's source. Read by the runtime login from l5/config.json. */
        projectSettings?: ProjectSettingsConfig;
        /** Declared workspace project ids. Read by cbeLogin.readProjectDependencies. */
        workspaceDependencies?: string[];
        /**
         * Organization identity source. Absent `organization` keeps the transitional onboarding.organizationSource.
         * A valid sites project file still wins over either source.
         */
        organization?: ProjectOrganizationConfig;
        /** Cadastro module tags. Supplied by the module, not fixed in the library. Does not gate organization identity. */
        onboarding?: ProjectOnboardingConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Brand identity shown by a header profile (resolved by AuraHeaderBase at runtime). */
    export interface AppHeaderBrand {
        title: string;
        subtitle?: string;
        /**
         * Inline SVG markup of the mark (what agentGenerateLogo writes). Preferred over `logoUrl`: an
         * inlined mark inherits `currentColor`, so it follows the design system in light and dark, which
         * an `<img src="*.svg">` cannot do (an external SVG never sees the page's CSS).
         */
        logoSvg?: string;
        /** `.svg` only — that is the asset kind that lands in dist. Colors are baked (no theme switch). */
        logoUrl?: string;
        logoAlt?: string;
        href?: string;
    }
    /** Optional actions a generated header may render (all off unless listed). */
    export type AppHeaderAction = 'language' | 'designSystem' | 'modules' | 'search' | 'user';
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        name?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ['actorSession.actorId', 'actorSession.scope'];
        readonly businessContext: readonly ['businessContext.activeCompanyId', 'businessContext.activeUnitId'];
        readonly currentWorkspace: readonly ['currentWorkspace.workspaceId'];
        readonly systemDefault: readonly ['systemDefault.now', 'systemDefault.uuid', 'systemDefault.locale'];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
