declare module "_102022_/l2/agentLucas.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/agentLucas" {
    import { IAgent } from '/_100554_/l2/aiAgentBase';
    import './_100554_widgetQuestionsForClarification';
    export function createAgent(): IAgent;
    export interface PayloadResultOk {
        pageHtml: string;
        result: mls.l4.BaseDefs;
    }
}
declare module "_102022_/l2/agentNewMiniApp.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/agentNewMiniApp" {
    import { IAgent } from '/_100554_/l2/aiAgentBase';
    import '/_100554_/l2/widgetQuestionsForClarification';
    export function createAgent(): IAgent;
    export interface PayloadUpdate {
        defs: mls.l4.BaseDefs;
        isUpdate: boolean;
    }
}
declare module "_102022_/l2/agentUpdateMiniApp.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/agentUpdateMiniApp" {
    import { IAgent } from '/_100554_/l2/aiAgentBase';
    import '/_100554_/l2/widgetQuestionsForClarification';
    export function createAgent(): IAgent;
    export interface PayloadOk {
        pageTs: string;
        pageHtml: string;
        defs: mls.l4.BaseDefs;
        pageLess?: string;
        isUpdate: boolean;
    }
    export interface PayloadUpdate {
        defs?: mls.l4.BaseDefs;
        prompt?: string;
        isUpdate: boolean;
    }
}
declare module "_102022_/l2/collabRunTime.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/config.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/config" {
    import { Aura } from '/_102020_/l2/aura';
    export var aura: Aura | undefined;
}
declare module "_102022_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/designSystem" {
    import { IDesignSystemTokens } from '/_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102022_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: {
            name: string;
            path: string;
            auth: string;
        }[];
    };
}
declare module "_102022_/l2/areaoftest/module.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/areaoftest/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: {
            pageName: string;
            title: string;
            auth: string;
            icon: string;
        }[];
    };
}
declare module "_102022_/l2/areaoftest/pageTest2.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/areaoftest/pageTest2" {
    import { CollabPageElement } from '/_100554_/l2/collabPageElement';
    export class PageTest2102022 extends CollabPageElement {
        initPage(): void;
        private cityA;
        private cityB;
        private cityOptions;
        constructor();
        private getTimeForZone;
        private getHourMinute;
        private computeDifference;
        private onCityAChange;
        private onCityBChange;
        render(): any;
    }
}
