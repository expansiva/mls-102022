/// <mls shortName="module" project="102022" enhancement="_blank" folder="reports" />
export const integrations = [];
export const tests = [];
